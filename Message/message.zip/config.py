# encoding=utf-8
'''
此文件用来存储安卓推送配置
'''
APPID = 'h37MITdUQM7PM6HoNfzCWA'
APPKEY = 'dFqqx2APui8mQJ7rKQHpG5'
MASTERSECRET = 'LdY3vm6Bm57Lzsuv9GUkX9'
CID=''
HOST = 'http://sdk.open.api.igexin.com/apiex.htm'