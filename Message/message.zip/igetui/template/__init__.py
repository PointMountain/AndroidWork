__author__ = 'wei'
__all__=["igt_base_template", "igt_link_template", "igt_notification_template", "igt_transmission_template" ]